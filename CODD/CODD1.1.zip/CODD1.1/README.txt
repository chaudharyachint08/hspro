1. After importing the CODD folder on to Eclipse/NetBeans IDE, running Main.java may 
throw an 'Project contains error' warning. This happens as SuanShu library is not
included in the libraries. Adding the library will remove the warning. Please note
that you can still go ahead with running CODD without SuanShu library, as it is needed
only for Time Scaling.

2. PostgreSQL Modifications folder is specific to PostgreSQL DB. Refer User Manual
for further details.