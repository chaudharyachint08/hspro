#!/bin/bash
javac -classpath .:../../PicassoCommon DisplayDiagramPacket.java

