#!/bin/bash
java -classpath .:../../PicassoCommon DisplayDiagramPacket

