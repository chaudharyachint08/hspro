This file intends to help users troubleshoot some problems which might occur when trying to use the shell scripts provided in this directory.

1. If the scripts do not run it is most probably due to the presence of some spurious control characters in the file. This problem can be solved by using the command:

#dos2unix filename

Do the same for every file that gives a problem

